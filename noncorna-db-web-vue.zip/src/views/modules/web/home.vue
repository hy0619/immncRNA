<template>
  <div>
    <el-row >
      <el-col :span="16">
        <div class="grid-content bg-purple">
          Welcome to NoncoRNA
          NoncoRNA: a database for experimentally supported Non-Coding RNA and Drug Target associations in Cancer. Cancer is an important cause of morbidity and mortality worldwide, in every world region, and irrespective of the level of human development. In addition, the incidence and mortality of cancer have increased rapidly worldwide in recent years. The reasons are complex, but drug resistance is the primary cause of clinical treatment failure. However, the mechanism of drug resistant to chemotherapeutic agents are not fully elucidated. Currently, more and more evidences have been proved that non-coding RNAs play critical roles in drug resistant. Whereas, the database association with drug resistant are only little. In addition, the information are incomprehensive.
          To fill this gap, we have developed NoncoRNA, a manually curated database of experimentally supported non-coding RNA and drug target associations in cancer. The current version of NoncoRNA contains 5,568 ncRNAs and 154 drugs in 134 cancers.
          photo_onephoto_onephoto_twophoto_three
          The feather of NoncoRNA including the following aspects:(1) The NoncoRNA is the first database that contains multiple ncRNAs, such as lncRNA, miRNA, circRNA and piRNA; (2) The NoncoRNA is the first database provides the relationship between circRNA, piRNA and drug resistant in cancer; (3) The NoncoRNA provides some relationship between ncRNAs and drug resistant in cancer.
          We highly recommend Google Chrome or Safari browser to have a better experience on NoncoRNA.
        </div>
      </el-col>
      <el-col :span="8">
        <div class="grid-content bg-purple">
          <el-row >nephoto_onephoto_twophoto_three
            The feather of NoncoRNA including the following aspects:(1) The NoncoRNA is the first database that contains multiple ncRNAs, such as lncRNA, miRNA, circRNA and piRNA; (2) The NoncoRNA is the first database provides the relationship between circRNA, piRNA and drug resistant in cancer; (3) The NoncoRNA provides some relationship between ncRNAs and drug resistant in cancer.
            We highly recommend Google Chrome or Safari brows</el-row>
          <el-row >2,nephoto_onephoto_twophoto_three
            The feather of NoncoRNA including the following aspects:(1) The NoncoRNA is the first database that contains multiple ncRNAs, such as lncRNA, miRNA, circRNA and piRNA; (2) The NoncoRNA is the first database provides the relationship between circRNA, piRNA and drug resistant in cancer; (3) The NoncoRNA provides some relationship between ncRNAs and drug resistant in cancer.
            We highly recommend Google Chrome or Safari brows</el-row>
          <el-row >3.nephoto_onephoto_twophoto_three
            The feather of NoncoRNA including the following aspects:(1) The NoncoRNA is the first database that contains multiple ncRNAs, such as lncRNA, miRNA, circRNA and piRNA; (2) The NoncoRNA is the first database provides the relationship between circRNA, piRNA and drug resistant in cancer; (3) The NoncoRNA provides some relationship between ncRNAs and drug resistant in cancer.
            We highly recommend Google Chrome or Safari brows</el-row>
        </div>
      </el-col>
    </el-row>


  </div>


</template>

<style>
.el-row {
  margin-bottom: 20px

}
.el-col {
  border-radius: 4px;
}

</style>

